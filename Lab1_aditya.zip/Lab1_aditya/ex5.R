x <-  sqrt(2)
x*x
x*x ==2
x*x - 2

all.equal(x*x,2) #nearly equal function
