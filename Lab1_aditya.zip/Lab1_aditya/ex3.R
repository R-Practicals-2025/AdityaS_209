a=1
b=2
c=4

#Logical operator
a&b #True, Non-zero number
!a<b | c>b #True, a is not less than b or c is greater than b. If either option is correct then give TRUE

