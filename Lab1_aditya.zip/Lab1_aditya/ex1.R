#Ex1 Arthematic operations
2.7/2 #1.35
5%/%2 #This gives the integer quotient value
10+5i/2 #10+2.5i

round(2.5) #round of 2.5 to 2
round(-2.5) #round of -2.5 to -2
2%/%4-1 # calculate quotient == 0, substracted 1 from it; Result = -1
2%/%4
3*2**2 # 3x(4) = 12
3**2*2 #(3)power2 x 2 = 18

7%/%4
7%4 #error
-7%4 #error
trunc(5.7)  # Truncated decimal values from the number
trunc(-5.7)

